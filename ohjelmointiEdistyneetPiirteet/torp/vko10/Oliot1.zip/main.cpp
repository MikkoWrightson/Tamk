#include<iostream>
#include<string>
#include"Henkilo.h"
using namespace std;

int main() {
	string hello("Hello");
	int pituus = hello.length();
	hello.append("Lisaa jotain");
	cout << hello << endl;
	system("pause");

	// Henkilon kalle luonti
	Henkilo kalle; 

	// Henkilo on luokka, kalle on luokan olio (muuttuja)
	kalle.setNimi("Kalle");
	kalle.setIka( 20 );

	Henkilo ville;
	ville.setNimi("Ville");
	ville.setIka( -100 );

	// Henkil�iden metodien kutsuminen
	kalle.tervehdi();
	ville.tervehdi();

	int x1 = kalle.getIka();

	system("pause");
	return EXIT_SUCCESS;
}