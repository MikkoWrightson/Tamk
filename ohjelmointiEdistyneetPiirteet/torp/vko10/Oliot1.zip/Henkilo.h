#pragma once
#include<string>
using namespace std;
// Henkilo -luokan esittely (.h)

// Class (luokka) tai struct koostuu
// 1. tietoj�senist� eli j�senmuuttujista, esim. nimi ja ik�
// - attribuutti, member variable, property
// 2. j�senfunktiosta eli metodeista
// - method, member function

class Henkilo {
public: // Luokan julkinen rajapinta (API), jonka kautta olioita k�ytet��n
	// Metodit, j�senfunktiot
	void tervehdi();
	void setIka(int uusiIka);
	int getIka();
	void setNimi(string uusiNimi);
	string getNimi();

private: // Kapseloitu tieto, yksityinen
	// Tietoj�senet, j�senmuuttujat
	string nimi;
	int ika;
};

