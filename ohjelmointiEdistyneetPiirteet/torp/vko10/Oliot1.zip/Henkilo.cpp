#include"Henkilo.h"
#include<string>
#include<iostream>
using namespace std;

// Henkilo -luokan toteutus (.cpp).
// Toteutuspuolella toteutetaan kaikki metodit (j�senfunktiot)
void Henkilo::tervehdi() {
	cout << "Hei nimeni on " << nimi << endl;
	cout << "Olen " << ika << " vuotias." << endl;
}
void Henkilo::setIka(int uusiIka) {
	if (uusiIka >= 0) {
		ika = uusiIka;
	}
}
int Henkilo::getIka() {
	return ika;
}
void Henkilo::setNimi(string uusiNimi) {
	nimi = uusiNimi;
}
string Henkilo::getNimi() {
	return nimi;
}